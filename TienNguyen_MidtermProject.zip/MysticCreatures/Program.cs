﻿using System;

namespace MysticCreatures
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game("~The World of Mystic Creatures~");
        }
    }
}
